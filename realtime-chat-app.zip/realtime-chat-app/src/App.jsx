import { useState } from 'react'
import {
  Moon,
  Sun,
  Send,
  Bell,
  Mic,
  Video,
  Users,
  CheckCheck,
} from 'lucide-react'

export default function App() {
  const [darkMode, setDarkMode] = useState(false)
  const [message, setMessage] = useState('')
  const [typing, setTyping] = useState(false)

  const [messages, setMessages] = useState([
    { text: 'Welcome to Realtime Chat 🚀', sender: 'other', read: true },
    { text: 'Dark mode enabled 😎', sender: 'me', read: true },
  ])

  const sendMessage = () => {
    if (!message.trim()) return

    setMessages([
      ...messages,
      {
        text: message,
        sender: 'me',
        read: true,
      },
    ])

    setMessage('')
  }

  const handleTyping = (e) => {
    setMessage(e.target.value)
    setTyping(true)

    setTimeout(() => {
      setTyping(false)
    }, 1000)
  }

  return (
    <div
      className={`min-h-screen flex items-center justify-center p-4 ${
        darkMode ? 'bg-gray-900' : 'bg-gray-100'
      }`}
    >
      <div
        className={`w-full max-w-md rounded-3xl shadow-2xl overflow-hidden ${
          darkMode ? 'bg-gray-800 text-white' : 'bg-white'
        }`}
      >
        <div className='bg-blue-600 text-white p-4 flex justify-between items-center'>
          <div>
            <h1 className='font-bold text-xl'>Realtime Chat</h1>
            <p className='text-sm opacity-80'>Online</p>
          </div>

          <div className='flex gap-3'>
            <Bell />
            <button onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? <Sun /> : <Moon />}
            </button>
          </div>
        </div>

        <div
          className={`h-96 overflow-y-auto p-4 space-y-3 ${
            darkMode ? 'bg-gray-900' : 'bg-gray-50'
          }`}
        >
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex ${
                msg.sender === 'me' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`px-4 py-2 rounded-2xl max-w-xs ${
                  msg.sender === 'me'
                    ? 'bg-blue-600 text-white'
                    : darkMode
                    ? 'bg-gray-700 text-white'
                    : 'bg-gray-200 text-black'
                }`}
              >
                <div>{msg.text}</div>

                {msg.sender === 'me' && (
                  <div className='flex justify-end mt-1 text-xs opacity-80'>
                    <CheckCheck size={14} />
                  </div>
                )}
              </div>
            </div>
          ))}

          {typing && (
            <div className='text-sm opacity-70'>Someone is typing...</div>
          )}
        </div>

        <div
          className={`p-4 border-t flex items-center gap-2 ${
            darkMode ? 'border-gray-700' : ''
          }`}
        >
          <button className='text-blue-500'>
            <Mic />
          </button>

          <button className='text-blue-500'>
            <Video />
          </button>

          <button className='text-blue-500'>
            <Users />
          </button>

          <input
            type='text'
            value={message}
            onChange={handleTyping}
            placeholder='Type a message...'
            className={`flex-1 px-4 py-2 rounded-xl outline-none ${
              darkMode
                ? 'bg-gray-700 text-white'
                : 'border focus:ring-2 focus:ring-blue-400'
            }`}
          />

          <button
            onClick={sendMessage}
            className='bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl'
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
