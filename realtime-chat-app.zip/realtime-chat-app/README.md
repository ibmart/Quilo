# Realtime Chat App

## Features
- Realtime Chat UI
- Dark Mode
- Typing Indicators
- Read Receipts
- Voice Note Button
- Video Call Button
- Group Chat Button
- Firebase Ready
- Vercel Ready

## Run Locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push project to GitHub
2. Import repo into Vercel
3. Deploy instantly

## Firebase
Replace the values in src/firebase.js with your Firebase credentials.
